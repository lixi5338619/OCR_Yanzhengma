from PIL import Image
import numpy as np
import os
from sklearn.neighbors import KNeighborsClassifier as knn
def img2vec(fname):
    '''将图片转为向量'''
    im = Image.open(fname).convert('L')
    im = im.resize((30,30))
    tmp = np.array(im)
    vec = tmp.ravel()
    return vec

tarin_img_path = 'train_data_img'
def split_data(paths):
    X = []
    y = []
    for i in os.listdir(tarin_img_path):
        path = os.path.join(tarin_img_path, i)
        fn_list = os.listdir(path)
        for name in fn_list:
            y.append(name[0])
            X.append(img2vec(os.path.join(path,name)))
    return X, y                 # x向量   y标签

def knn_clf(X_train,label):
    '''构建分类器'''
    clf = knn()
    clf.fit(X_train,label)
    return clf

def knn_shib(test_img):
    X_train,y_label = split_data(tarin_img_path)
    clf = knn_clf(X_train,y_label)
    result = clf.predict([img2vec(test_img)])
    return result

