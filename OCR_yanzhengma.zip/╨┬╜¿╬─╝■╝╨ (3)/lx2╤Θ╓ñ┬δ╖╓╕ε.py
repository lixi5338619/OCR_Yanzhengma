import os
from PIL import Image
from sklearn.externals import joblib
import time
def read_img():
    img_array = []
    img_lable = []
    file_list = os.listdir('./test_img')
    for file in file_list:
        try:
            image = file
            # img_name = file.replace(' ','').split('.')[0]
            img_array.append(image)
            # img_lable.append(img_name)
        except:
            print(f'{file}:图像已损坏')
            os.remove('./test_img/'+file)
    return img_array


def sliceImg(img_path, count = 4):
    if not os.path.exists('train_data_img'):
        os.mkdir('train_data_img')
    for i in range(10):
        if not os.path.exists(f'train_data_img/{i}'):
            os.mkdir(f'train_data_img/{i}')
    img = Image.open('./test_img/'+img_path)
    w, h = img.size
    eachWidth = int((w - 17) / count)
    img_path = img_path.replace(' ', '').split('.')[0]

    for i in range(count):
        box = (i * eachWidth, 0, (i + 1) * eachWidth, h)
        img.crop(box).save(f'./train_data_img/{img_path[i]}/'+img_path[i]+ str(time.time()) + ".png")

if __name__ == '__main__':
    img_array = read_img()
    for i in img_array:
        print(i)
        sliceImg(i)

